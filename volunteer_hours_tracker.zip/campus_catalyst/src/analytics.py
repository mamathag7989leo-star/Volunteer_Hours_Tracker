"""
analytics.py - Executive summary generation, metrics calculation, and anomaly detection.
Computes comprehensive aggregations, volunteer rankings, category distributions,
and flags high-intensity or unusual entries.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Any, Tuple, Optional
from models import VolunteerRecord


# Standard community service award milestone thresholds (hours)
MILESTONES = {
    "Bronze Service Award": 20.0,
    "Silver Service Award": 50.0,
    "Gold Leadership Award": 100.0,
    "Presidential Diamond Pin": 250.0,
}


@dataclass
class ExecutiveSummary:
    total_records: int = 0
    total_hours: float = 0.0
    avg_hours_per_session: float = 0.0
    min_hours_session: float = 0.0
    max_hours_session: float = 0.0
    unique_volunteers: int = 0
    unique_organizations: int = 0
    unique_categories: int = 0
    category_breakdown: Dict[str, float] = field(default_factory=dict)
    organization_breakdown: Dict[str, float] = field(default_factory=dict)
    volunteer_leaderboard: List[Dict[str, Any]] = field(default_factory=list)
    monthly_trends: Dict[str, float] = field(default_factory=dict)
    anomalies: List[Dict[str, Any]] = field(default_factory=list)
    milestones_achieved: Dict[str, List[str]] = field(default_factory=dict)


def compute_executive_summary(records: List[VolunteerRecord]) -> ExecutiveSummary:
    """Computes comprehensive executive analytics from a list of volunteer records."""
    if not records:
        return ExecutiveSummary()

    total_records = len(records)
    total_hours = sum(r.hours for r in records)
    avg_hours = total_hours / total_records if total_records > 0 else 0.0
    min_hours = min(r.hours for r in records)
    max_hours = max(r.hours for r in records)

    cat_hours: Dict[str, float] = defaultdict(float)
    org_hours: Dict[str, float] = defaultdict(float)
    vol_hours: Dict[str, float] = defaultdict(float)
    vol_sessions: Dict[str, int] = defaultdict(int)
    monthly: Dict[str, float] = defaultdict(float)
    vol_date_map: Dict[Tuple[str, str], float] = defaultdict(float)

    anomalies: List[Dict[str, Any]] = []

    for r in records:
        cat_hours[r.category] += r.hours
        org_hours[r.organization] += r.hours
        vol_hours[r.volunteer_name] += r.hours
        vol_sessions[r.volunteer_name] += 1

        # Extract month YYYY-MM
        try:
            month_key = r.date[:7]
        except (IndexError, TypeError):
            month_key = "Unknown"
        monthly[month_key] += r.hours

        # Anomaly Check 1: Single session >= 10.0 hours
        if r.hours >= 10.0:
            anomalies.append({
                "type": "HIGH_SINGLE_SESSION",
                "severity": "WARNING" if r.hours < 16.0 else "CRITICAL",
                "record_id": r.record_id,
                "volunteer": r.volunteer_name,
                "date": r.date,
                "hours": r.hours,
                "message": f"Single session exceeds recommended limit: {r.hours:.1f} hrs on {r.date} ({r.organization})"
            })

        # Track multiple sessions per day by same volunteer
        vol_date_map[(r.volunteer_name, r.date)] += r.hours

    # Anomaly Check 2: Total daily hours across sessions >= 14.0 hours
    for (vol, v_date), day_hrs in vol_date_map.items():
        if day_hrs >= 14.0:
            anomalies.append({
                "type": "EXCESSIVE_DAILY_HOURS",
                "severity": "CRITICAL",
                "record_id": "N/A",
                "volunteer": vol,
                "date": v_date,
                "hours": round(day_hrs, 2),
                "message": f"Cumulative volunteer time on {v_date} reached {day_hrs:.1f} hrs across sessions."
            })

    # Volunteer leaderboard sorted by total hours descending
    leaderboard = []
    for vol, hrs in sorted(vol_hours.items(), key=lambda x: x[1], reverse=True):
        leaderboard.append({
            "volunteer": vol,
            "total_hours": round(hrs, 2),
            "sessions": vol_sessions[vol],
            "avg_hours": round(hrs / vol_sessions[vol], 2)
        })

    # Milestone checking
    milestones_achieved: Dict[str, List[str]] = defaultdict(list)
    for entry in leaderboard:
        vol = entry["volunteer"]
        hrs = entry["total_hours"]
        for badge, threshold in MILESTONES.items():
            if hrs >= threshold:
                milestones_achieved[badge].append(f"{vol} ({hrs:.1f} hrs)")

    # Sort categories and organizations
    sorted_cats = {k: round(v, 2) for k, v in sorted(cat_hours.items(), key=lambda x: x[1], reverse=True)}
    sorted_orgs = {k: round(v, 2) for k, v in sorted(org_hours.items(), key=lambda x: x[1], reverse=True)}
    sorted_monthly = {k: round(v, 2) for k, v in sorted(monthly.items())}

    return ExecutiveSummary(
        total_records=total_records,
        total_hours=round(total_hours, 2),
        avg_hours_per_session=round(avg_hours, 2),
        min_hours_session=round(min_hours, 2),
        max_hours_session=round(max_hours, 2),
        unique_volunteers=len(vol_hours),
        unique_organizations=len(org_hours),
        unique_categories=len(cat_hours),
        category_breakdown=sorted_cats,
        organization_breakdown=sorted_orgs,
        volunteer_leaderboard=leaderboard,
        monthly_trends=sorted_monthly,
        anomalies=anomalies,
        milestones_achieved=dict(milestones_achieved)
    )


def filter_records(
    records: List[VolunteerRecord],
    keyword: Optional[str] = None,
    volunteer: Optional[str] = None,
    organization: Optional[str] = None,
    category: Optional[str] = None,
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    min_hours: Optional[float] = None,
    max_hours: Optional[float] = None,
) -> List[VolunteerRecord]:
    """Filters records based on flexible multi-criteria search."""
    results = records

    if keyword:
        results = [r for r in results if r.matches_keyword(keyword)]

    if volunteer:
        v_low = volunteer.lower().strip()
        results = [r for r in results if v_low in r.volunteer_name.lower()]

    if organization:
        o_low = organization.lower().strip()
        results = [r for r in results if o_low in r.organization.lower()]

    if category:
        c_low = category.lower().strip()
        results = [r for r in results if c_low in r.category.lower()]

    if date_start:
        results = [r for r in results if r.date >= date_start]

    if date_end:
        results = [r for r in results if r.date <= date_end]

    if min_hours is not None:
        results = [r for r in results if r.hours >= min_hours]

    if max_hours is not None:
        results = [r for r in results if r.hours <= max_hours]

    return results
