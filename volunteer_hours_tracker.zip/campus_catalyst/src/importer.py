"""
importer.py - Robust bulk CSV dataset importer with row-by-row defensive validation.
Parses legacy and external volunteer datasets, logs formatting discrepancies,
and cleanly imports valid entries into the database.
"""

import csv
import os
from typing import List, Tuple, Dict, Any
from models import VolunteerRecord
from validators import validate_date_string, validate_hours, sanitize_text
from storage import StorageManager


class BulkImportReport:
    """Summary of bulk CSV ingestion."""
    def __init__(self, filename: str):
        self.filename = filename
        self.total_rows_read: int = 0
        self.valid_rows_imported: int = 0
        self.skipped_rows: int = 0
        self.errors: List[Dict[str, Any]] = []

    def add_error(self, row_idx: int, reason: str, raw_row: Dict[str, Any]) -> None:
        self.skipped_rows += 1
        self.errors.append({
            "row_index": row_idx,
            "reason": reason,
            "raw_data": raw_row
        })

    def print_summary(self) -> None:
        print(f"\nBulk Import Results for: {os.path.basename(self.filename)}")
        print(f"  Rows Read        : {self.total_rows_read}")
        print(f"  Successfully Added: {self.valid_rows_imported}")
        print(f"  Skipped (Errors) : {self.skipped_rows}")
        if self.errors:
            print("\n  Row-by-Row Error Log:")
            for err in self.errors[:10]:
                print(f"    - Line {err['row_index']}: {err['reason']}")
            if len(self.errors) > 10:
                print(f"    - ... and {len(self.errors) - 10} more errors.")


def import_csv_dataset(
    filepath: str,
    existing_records: List[VolunteerRecord]
) -> Tuple[List[VolunteerRecord], BulkImportReport]:
    """
    Ingests CSV file and validates every row defensively.
    Returns: (list_of_newly_imported_records, report_object)
    """
    report = BulkImportReport(filepath)
    new_records: List[VolunteerRecord] = []

    if not os.path.exists(filepath):
        report.add_error(0, f"File does not exist: {filepath}", {})
        return new_records, report

    # Combine existing + new to ensure globally unique sequential IDs
    combined_pool = list(existing_records)

    try:
        with open(filepath, "r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                report.add_error(0, "CSV file is empty or has no header row.", {})
                return new_records, report

            # Standardize header keys by stripping and lowercasing
            clean_headers = {col.strip().lower(): col for col in reader.fieldnames if col}

            def get_col(row_dict: dict, *candidates: str) -> str:
                for c in candidates:
                    for h_clean, orig in clean_headers.items():
                        if c == h_clean or c in h_clean:
                            return row_dict.get(orig, "").strip()
                return ""

            for row_idx, row in enumerate(reader, start=2):  # start=2 because line 1 is header
                report.total_rows_read += 1

                # Extract required fields with flexible naming
                vol_name = get_col(row, "volunteer_name", "volunteer", "name", "student")
                date_val = get_col(row, "date", "service_date", "day")
                org_val = get_col(row, "organization", "org", "partner", "agency")
                cat_val = get_col(row, "category", "activity_type", "type")
                hours_val = get_col(row, "hours", "hours_served", "duration")
                desc_val = get_col(row, "description", "details", "notes", "activity")
                rec_id = get_col(row, "record_id", "id")
                sup_val = get_col(row, "supervisor", "coordinator") or "External CSV"

                # Validation 1: Volunteer Name
                if not vol_name or len(vol_name) < 2:
                    report.add_error(row_idx, "Volunteer name missing or under 2 chars.", row)
                    continue

                # Validation 2: Date
                is_valid_date, date_err, _ = validate_date_string(date_val)
                if not is_valid_date:
                    report.add_error(row_idx, f"Invalid date '{date_val}': {date_err}", row)
                    continue

                # Validation 3: Organization
                if not org_val:
                    report.add_error(row_idx, "Organization name cannot be empty.", row)
                    continue

                # Validation 4: Category
                if not cat_val:
                    cat_val = "Community Service"

                # Validation 5: Hours
                is_valid_hrs, hrs_err, parsed_hrs = validate_hours(hours_val)
                if not is_valid_hrs:
                    report.add_error(row_idx, f"Invalid hours '{hours_val}': {hrs_err}", row)
                    continue

                # Validation 6: ID generation if not provided
                if not rec_id:
                    rec_id = StorageManager.generate_next_id(combined_pool)

                record = VolunteerRecord(
                    record_id=rec_id,
                    volunteer_name=vol_name,
                    date=date_val,
                    organization=org_val,
                    category=cat_val,
                    hours=parsed_hrs,
                    description=desc_val or "Imported via CSV batch.",
                    supervisor=sup_val
                )

                new_records.append(record)
                combined_pool.append(record)
                report.valid_rows_imported += 1

    except Exception as e:
        report.add_error(0, f"Fatal read error processing CSV file: {e}", {})

    return new_records, report
