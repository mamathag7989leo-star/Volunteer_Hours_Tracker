"""
cli.py - Interactive terminal console interface for Volunteer Hours Tracker.
Features clean ASCII banners, formatted tabular displays, pagination,
guided workflows, and seamless navigation.
"""

import os
import sys
from typing import List, Optional
from models import VolunteerRecord, CATEGORIES
from storage import StorageManager, DEFAULT_JSON_PATH, DEFAULT_CSV_PATH
from validators import (
    prompt_non_empty, prompt_date, prompt_hours,
    prompt_category_choice, prompt_yes_no, sanitize_text
)
from analytics import compute_executive_summary, filter_records, MILESTONES
from exporters import export_markdown_report, export_plain_text_audit
from importer import import_csv_dataset


BANNER = """
================================================================================
 _    _ _____ _     _   _ _   _ _____ _____ _____ ____  
| |  | |  _  | |   | | | | \ | |_   _| ____| ____|  _ \ 
| |  | | | | | |   | | | |  \| | | | |  _| |  _| | |_) |
\ \_/ /| |_| | |___| |_| | |\  | | | | |___| |___|  _ < 
 \___/  \_____/_____|___/|_| \_| |_| |_____|_____|_| \_\ 
                VOLUNTEER HOURS TRACKER
================================================================================
"""


def clear_screen():
    """Clear terminal console if possible."""
    os.system("cls" if os.name == "nt" else "clear")


def print_table(records: List[VolunteerRecord], page_size: int = 12):
    """Prints a clean, fixed-width ASCII table with pagination."""
    if not records:
        print("\n  [No volunteer records found to display.]\n")
        return

    total_records = len(records)
    current_page = 0
    total_pages = (total_records + page_size - 1) // page_size

    while True:
        start_idx = current_page * page_size
        end_idx = min(start_idx + page_size, total_records)
        page_records = records[start_idx:end_idx]

        print("\n" + "=" * 96)
        print(f" {'ID':<10} | {'DATE':<11} | {'VOLUNTEER':<18} | {'HOURS':<6} | {'CATEGORY':<20} | {'ORGANIZATION':<18}")
        print("-" * 96)

        for r in page_records:
            v_name = (r.volunteer_name[:16] + "..") if len(r.volunteer_name) > 18 else r.volunteer_name
            cat = (r.category[:18] + "..") if len(r.category) > 20 else r.category
            org = (r.organization[:16] + "..") if len(r.organization) > 18 else r.organization
            print(f" {r.record_id:<10} | {r.date:<11} | {v_name:<18} | {r.hours:<6.2f} | {cat:<20} | {org:<18}")

        print("=" * 96)
        print(f"  Showing page {current_page + 1} of {total_pages} (Total: {total_records} records)")

        if total_pages <= 1:
            break

        nav = input("  [N]ext Page | [P]revious Page | [Q]uit Table: ").strip().lower()
        if nav in ("n", "next") and current_page < total_pages - 1:
            current_page += 1
        elif nav in ("p", "prev", "previous") and current_page > 0:
            current_page -= 1
        elif nav in ("q", "quit", "exit", ""):
            break


class CommandLineInterface:
    """Primary application controller driving user workflows."""

    def __init__(self, storage_manager: Optional[StorageManager] = None):
        self.storage = storage_manager or StorageManager()
        self.records, init_msg = self.storage.load_records()
        self.init_msg = init_msg

    def run(self):
        """Main application lifecycle loop."""
        clear_screen()
        print(BANNER)
        if self.init_msg:
            print(f"[*] {self.init_msg}\n")
        print(f"[*] System ready. Currently tracking {len(self.records)} volunteer service records.\n")

        while True:
            self.display_main_menu()
            choice = input("\nSelect an action (0-9): ").strip()

            try:
                if choice == "1":
                    self.action_log_activity()
                elif choice == "2":
                    self.action_view_all()
                elif choice == "3":
                    self.action_search_filter()
                elif choice == "4":
                    self.action_analytics_dashboard()
                elif choice == "5":
                    self.action_view_anomalies()
                elif choice == "6":
                    self.action_export_reports()
                elif choice == "7":
                    self.action_bulk_import_csv()
                elif choice == "8":
                    self.action_seed_sample_data()
                elif choice == "9":
                    self.action_launch_gui()
                elif choice == "0":
                    print("\n[OK] Changes saved. Thank you for making an impact with Volunteer Hours Tracker!")
                    break
                else:
                    print("  [!] Invalid selection. Please enter a number between 0 and 9.")
            except (KeyboardInterrupt, EOFError):
                print("\n\nOperation cancelled. Returning to main menu.")
            except Exception as e:
                print(f"\n[!] Unexpected error encountered: {e}")

    def display_main_menu(self):
        print("\n" + "-" * 50)
        print("                 MAIN MENU")
        print("-" * 50)
        print("  [1]  Log New Volunteer Service Entry")
        print("  [2]  View All Records (Paginated Table)")
        print("  [3]  Search & Filter Records")
        print("  [4]  Executive Analytics & Impact Dashboard")
        print("  [5]  Audit Flags & Anomaly Warning Indicators")
        print("  [6]  Export Reports (Markdown, Audit Log, CSV)")
        print("  [7]  Bulk Import Dataset from External CSV")
        print("  [8]  Reset / Seed Realistic 40+ Sample Records")
        print("  [9]  Launch Desktop GUI View (Tkinter)")
        print("  [0]  Save & Exit")
        print("-" * 50)

    def action_log_activity(self):
        print("\n--- LOG NEW VOLUNTEER ACTIVITY ---")
        new_id = self.storage.generate_next_id(self.records)
        print(f"Assigned Record ID: {new_id}")

        vol_name = prompt_non_empty("Volunteer Full Name: ")
        date_val = prompt_date("Activity Date (YYYY-MM-DD) [Enter for today]: ")
        org = prompt_non_empty("Partner Organization / Cause: ")
        category = prompt_category_choice(CATEGORIES)
        hours = prompt_hours("Service Hours (e.g., 2.5): ")
        desc = prompt_non_empty("Activity Description / Impact Notes: ", min_len=4, max_len=200)
        supervisor = prompt_non_empty("Supervisor / Witness [Enter 'Self' if none]: ", min_len=1, max_len=60)

        record = VolunteerRecord(
            record_id=new_id,
            volunteer_name=vol_name,
            date=date_val,
            organization=org,
            category=category,
            hours=hours,
            description=desc,
            supervisor=supervisor
        )

        self.records.append(record)
        if self.storage.save_records(self.records):
            print(f"\n[SUCCESS] Record {new_id} successfully logged and persisted!")
        else:
            print("\n[ERROR] Failed to save record to disk.")

    def action_view_all(self):
        print("\n--- ALL RECORDED VOLUNTEER HOURS ---")
        sorted_records = sorted(self.records, key=lambda r: r.date, reverse=True)
        print_table(sorted_records)

    def action_search_filter(self):
        print("\n--- SEARCH & FILTER RECORDS ---")
        print("Leave any field blank to skip that filter criteria.")

        keyword = input("General Keyword Search (name, org, desc, ID): ").strip() or None
        volunteer = input("Specific Volunteer Name filter: ").strip() or None
        org = input("Organization filter: ").strip() or None
        cat = input("Category filter: ").strip() or None

        results = filter_records(
            self.records,
            keyword=keyword,
            volunteer=volunteer,
            organization=org,
            category=cat
        )

        print(f"\nFound {len(results)} matching records:")
        print_table(results)

    def action_analytics_dashboard(self):
        print("\n--- EXECUTIVE IMPACT & ANALYTICS DASHBOARD ---")
        summary = compute_executive_summary(self.records)

        print("=" * 60)
        print(f"  Total Service Hours Logged : {summary.total_hours:,.2f} hrs")
        print(f"  Total Activities Logged    : {summary.total_records}")
        print(f"  Average Hours / Session    : {summary.avg_hours_per_session:.2f} hrs")
        print(f"  Shortest / Longest Session : {summary.min_hours_session:.1f}h / {summary.max_hours_session:.1f}h")
        print(f"  Active Student Volunteers  : {summary.unique_volunteers}")
        print(f"  Partner Organizations      : {summary.unique_organizations}")
        print("=" * 60)

        print("\nHOURS BY CATEGORY:")
        for cat, hrs in summary.category_breakdown.items():
            bar_len = int((hrs / summary.total_hours) * 30) if summary.total_hours > 0 else 0
            bar = "#" * bar_len
            pct = (hrs / summary.total_hours * 100) if summary.total_hours > 0 else 0
            print(f"  {cat[:24]:<24} | {hrs:6.1f}h ({pct:4.1f}%) {bar}")

        print("\nVOLUNTEER LEADERBOARD (Top 5):")
        for idx, entry in enumerate(summary.volunteer_leaderboard[:5], 1):
            print(f"  #{idx} {entry['volunteer']:<20} : {entry['total_hours']:6.1f} hrs ({entry['sessions']} sessions)")

        if summary.milestones_achieved:
            print("\nCOMMUNITY SERVICE HONORS & AWARDS:")
            for badge, holders in summary.milestones_achieved.items():
                print(f"  * {badge}: {', '.join(holders)}")

        if summary.anomalies:
            print(f"\n[!] Notice: {len(summary.anomalies)} threshold warning(s) detected. View Option 5 for details.")

    def action_view_anomalies(self):
        print("\n--- AUDIT FLAGS & THRESHOLD WARNINGS ---")
        summary = compute_executive_summary(self.records)

        if not summary.anomalies:
            print("  [OK] No anomalous entries detected. All records within standard parameters.")
            return

        print(f"Detected {len(summary.anomalies)} potential outlier(s) / excessive hour entries:\n")
        for idx, a in enumerate(summary.anomalies, 1):
            flag = "[CRITICAL ALERT]" if a["severity"] == "CRITICAL" else "[AUDIT NOTICE]"
            print(f"  {idx}. {flag} {a['date']} | Volunteer: {a['volunteer']}")
            print(f"     Details: {a['message']}")
        print()

    def action_export_reports(self):
        print("\n--- MULTI-FORMAT REPORT EXPORT ---")
        summary = compute_executive_summary(self.records)
        export_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "exports")
        os.makedirs(export_dir, exist_ok=True)

        md_path = os.path.join(export_dir, "volunteer_audit_report.md")
        txt_path = os.path.join(export_dir, "volunteer_audit_log.txt")
        csv_path = os.path.join(export_dir, "volunteer_records_export.csv")

        ok_md = export_markdown_report(summary, self.records, md_path)
        ok_txt = export_plain_text_audit(summary, self.records, txt_path)
        ok_csv = self.storage.export_csv(self.records, csv_path)

        if ok_md and ok_txt and ok_csv:
            print("[SUCCESS] All export reports generated successfully:")
            print(f"  - Markdown Report : {md_path}")
            print(f"  - Plain Text Log  : {txt_path}")
            print(f"  - CSV Data Export : {csv_path}")
        else:
            print("[!] One or more export operations failed.")

    def action_bulk_import_csv(self):
        print("\n--- BULK IMPORT DATASET FROM CSV ---")
        filepath = input("Enter path to CSV file to import: ").strip().strip('"')

        if not os.path.exists(filepath):
            print(f"  [Error] File not found: {filepath}")
            return

        new_recs, report = import_csv_dataset(filepath, self.records)
        report.print_summary()

        if new_recs:
            if prompt_yes_no(f"Do you want to append these {len(new_recs)} records to your database?"):
                self.records.extend(new_recs)
                self.storage.save_records(self.records)
                print(f"[SUCCESS] Appended {len(new_recs)} records. Total records now: {len(self.records)}")
            else:
                print("Import cancelled by user.")

    def action_seed_sample_data(self):
        print("\n--- SEED SAMPLE DATASET ---")
        if self.records and not prompt_yes_no("This will replace current records with 45 realistic sample entries. Continue?"):
            return

        from sample_data import generate_sample_records
        self.records = generate_sample_records()
        self.storage.save_records(self.records)
        print(f"[SUCCESS] Loaded {len(self.records)} realistic volunteer records with diverse test cases!")

    def action_launch_gui(self):
        print("\n--- LAUNCHING DESKTOP GUI ---")
        try:
            from gui import launch_gui_window
            print("Opening Tkinter graphical window...")
            launch_gui_window(self.records, self.storage)
            # Reload in case changes were made in GUI
            self.records, _ = self.storage.load_records()
        except Exception as e:
            print(f"Could not open GUI in this environment ({e}). Terminal CLI remains fully functional.")
