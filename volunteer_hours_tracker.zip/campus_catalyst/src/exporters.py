"""
exporters.py - Multi-format export engine for external audits and reviews.
Generates structured Markdown reports, plain-text audit logs, and standardized CSV exports.
"""

import os
import csv
from datetime import datetime
from typing import List
from models import VolunteerRecord
from analytics import ExecutiveSummary


def export_markdown_report(
    summary: ExecutiveSummary,
    records: List[VolunteerRecord],
    output_path: str
) -> bool:
    """Exports a formatted Markdown report suitable for publishing or grading review."""
    try:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("# Volunteer Hours Tracker - Executive Audit Report\n\n")
            f.write(f"*Generated on: {now_str}*\n\n")
            f.write("---\n\n")

            f.write("## 1. Executive Summary Metrics\n\n")
            f.write(f"- **Total Records Logged:** {summary.total_records}\n")
            f.write(f"- **Total Service Hours:** {summary.total_hours:,.2f} hrs\n")
            f.write(f"- **Average Hours per Session:** {summary.avg_hours_per_session:.2f} hrs\n")
            f.write(f"- **Session Duration Range:** {summary.min_hours_session:.2f} hrs to {summary.max_hours_session:.2f} hrs\n")
            f.write(f"- **Active Volunteers:** {summary.unique_volunteers}\n")
            f.write(f"- **Partner Organizations:** {summary.unique_organizations}\n")
            f.write(f"- **Community Impact Categories:** {summary.unique_categories}\n\n")

            f.write("## 2. Category Distribution\n\n")
            f.write("| Category | Service Hours | % of Total |\n")
            f.write("| :--- | :--- | :--- |\n")
            for cat, hrs in summary.category_breakdown.items():
                pct = (hrs / summary.total_hours * 100) if summary.total_hours > 0 else 0
                f.write(f"| {cat} | {hrs:.2f} hrs | {pct:.1f}% |\n")
            f.write("\n")

            f.write("## 3. Volunteer Leaderboard & Recognition\n\n")
            f.write("| Rank | Volunteer Name | Total Hours | Sessions | Avg Session |\n")
            f.write("| :--- | :--- | :--- | :--- | :--- |\n")
            for rank, entry in enumerate(summary.volunteer_leaderboard, 1):
                f.write(f"| #{rank} | {entry['volunteer']} | {entry['total_hours']:.2f} hrs | {entry['sessions']} | {entry['avg_hours']:.2f} hrs |\n")
            f.write("\n")

            if summary.milestones_achieved:
                f.write("## 4. Community Service Honors & Badges\n\n")
                for badge, holders in summary.milestones_achieved.items():
                    f.write(f"- **{badge}:** {', '.join(holders)}\n")
                f.write("\n")

            if summary.anomalies:
                f.write("## 5. Audit Flags & Threshold Alerts\n\n")
                f.write("| Severity | Date | Volunteer | Details |\n")
                f.write("| :--- | :--- | :--- | :--- |\n")
                for a in summary.anomalies:
                    f.write(f"| `{a['severity']}` | {a['date']} | {a['volunteer']} | {a['message']} |\n")
                f.write("\n")

            f.write("## 6. Complete Activity Audit Trail\n\n")
            f.write("| Record ID | Date | Volunteer | Organization | Category | Hours | Description |\n")
            f.write("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n")
            for r in records:
                clean_desc = r.description.replace("|", "-")
                f.write(f"| {r.record_id} | {r.date} | {r.volunteer_name} | {r.organization} | {r.category} | {r.hours:.2f} | {clean_desc} |\n")

        return True
    except Exception as e:
        print(f"  [!] Markdown export failed: {e}")
        return False


def export_plain_text_audit(
    summary: ExecutiveSummary,
    records: List[VolunteerRecord],
    output_path: str
) -> bool:
    """Exports a formatted plain-text log for auditing."""
    try:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        with open(output_path, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write("VOLUNTEER HOURS TRACKER - AUDIT TRAIL LOG\n")
            f.write(f"Generated: {now_str}\n")
            f.write("=" * 80 + "\n\n")

            f.write("EXECUTIVE SUMMARY:\n")
            f.write(f"  Total Records Logged     : {summary.total_records}\n")
            f.write(f"  Total Service Hours      : {summary.total_hours:.2f} hrs\n")
            f.write(f"  Average Hours/Session    : {summary.avg_hours_per_session:.2f} hrs\n")
            f.write(f"  Active Volunteers        : {summary.unique_volunteers}\n")
            f.write(f"  Partner Organizations    : {summary.unique_organizations}\n\n")

            f.write("-" * 80 + "\n")
            f.write("CATEGORY BREAKDOWN:\n")
            for cat, hrs in summary.category_breakdown.items():
                pct = (hrs / summary.total_hours * 100) if summary.total_hours > 0 else 0
                f.write(f"  - {cat.ljust(32)}: {hrs:7.2f} hrs ({pct:5.1f}%)\n")
            f.write("\n")

            if summary.anomalies:
                f.write("-" * 80 + "\n")
                f.write("FLAGGED ENTRIES / ANOMALIES:\n")
                for a in summary.anomalies:
                    f.write(f"  [{a['severity']}] {a['date']} - {a['volunteer']}: {a['message']}\n")
                f.write("\n")

            f.write("-" * 80 + "\n")
            f.write("CHRONOLOGICAL RECORD LOG:\n")
            f.write(f"{'ID':<10} {'DATE':<12} {'VOLUNTEER':<20} {'HOURS':<8} {'ORGANIZATION':<22} {'CATEGORY'}\n")
            f.write("-" * 80 + "\n")
            for r in records:
                f.write(f"{r.record_id:<10} {r.date:<12} {r.volunteer_name[:19]:<20} {r.hours:<8.2f} {r.organization[:20]:<22} {r.category}\n")

        return True
    except Exception as e:
        print(f"  [!] Plain text export failed: {e}")
        return False
