"""
gui.py - Lightweight Graphical User Interface (Tkinter) for Volunteer Hours Tracker.
Zero-dependency GUI providing visual table browsing, entry logging, and analytics.
"""

import tkinter as tk
from tkinter import ttk, messagebox
from typing import List
from models import VolunteerRecord, CATEGORIES
from storage import StorageManager
from validators import validate_date_string, validate_hours
from analytics import compute_executive_summary


class CampusCatalystGUI:
    """Tkinter Desktop Window for Volunteer Hours Tracker."""

    def __init__(self, root: tk.Tk, records: List[VolunteerRecord], storage: StorageManager):
        self.root = root
        self.records = records
        self.storage = storage
        self.root.title("Volunteer Hours Tracker")
        self.root.geometry("980x640")
        self.root.minsize(800, 500)

        self.setup_styles()
        self.create_widgets()
        self.refresh_table()
        self.update_summary_cards()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview.Heading", font=("Helvetica", 10, "bold"), background="#e1e1e1")
        style.configure("Treeview", font=("Helvetica", 9), rowheight=24)
        style.configure("Header.TLabel", font=("Helvetica", 15, "bold"), foreground="#1a365d")
        style.configure("Stat.TLabel", font=("Helvetica", 11, "bold"), foreground="#2b6cb0")

    def create_widgets(self):
        # Top Header & Stats Frame
        top_frame = ttk.Frame(self.root, padding="10")
        top_frame.pack(fill=tk.X)

        header_lbl = ttk.Label(top_frame, text="Volunteer Hours Tracker | Executive Dashboard", style="Header.TLabel")
        header_lbl.pack(side=tk.LEFT)

        self.stats_label = ttk.Label(top_frame, text="", style="Stat.TLabel")
        self.stats_label.pack(side=tk.RIGHT)

        # Search Bar Frame
        search_frame = ttk.Frame(self.root, padding="5 10")
        search_frame.pack(fill=tk.X)

        ttk.Label(search_frame, text="Quick Search:").pack(side=tk.LEFT, padx=5)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.filter_table())
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=35)
        search_entry.pack(side=tk.LEFT, padx=5)

        btn_add = ttk.Button(search_frame, text="+ Log New Entry", command=self.open_add_dialog)
        btn_add.pack(side=tk.RIGHT, padx=5)

        # Table Frame
        table_frame = ttk.Frame(self.root, padding="10")
        table_frame.pack(fill=tk.BOTH, expand=True)

        columns = ("id", "date", "name", "category", "hours", "org", "desc")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")

        self.tree.heading("id", text="ID")
        self.tree.heading("date", text="Date")
        self.tree.heading("name", text="Volunteer")
        self.tree.heading("category", text="Category")
        self.tree.heading("hours", text="Hours")
        self.tree.heading("org", text="Organization")
        self.tree.heading("desc", text="Activity Description")

        self.tree.column("id", width=75, anchor=tk.CENTER)
        self.tree.column("date", width=90, anchor=tk.CENTER)
        self.tree.column("name", width=140)
        self.tree.column("category", width=160)
        self.tree.column("hours", width=65, anchor=tk.E)
        self.tree.column("org", width=160)
        self.tree.column("desc", width=240)

        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def update_summary_cards(self):
        summary = compute_executive_summary(self.records)
        self.stats_label.config(
            text=f"Total: {summary.total_records} records | {summary.total_hours:,.1f} hrs | Avg: {summary.avg_hours_per_session:.1f}h"
        )

    def refresh_table(self, records: List[VolunteerRecord] = None):
        if records is None:
            records = self.records

        for row in self.tree.get_children():
            self.tree.delete(row)

        for r in records:
            self.tree.insert("", tk.END, values=(
                r.record_id, r.date, r.volunteer_name, r.category,
                f"{r.hours:.2f}", r.organization, r.description
            ))

    def filter_table(self):
        q = self.search_var.get().lower().strip()
        if not q:
            self.refresh_table()
            return
        filtered = [r for r in self.records if r.matches_keyword(q)]
        self.refresh_table(filtered)

    def open_add_dialog(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Log New Activity")
        dialog.geometry("450x420")
        dialog.transient(self.root)
        dialog.grab_set()

        form = ttk.Frame(dialog, padding="15")
        form.pack(fill=tk.BOTH, expand=True)

        new_id = self.storage.generate_next_id(self.records)

        ttk.Label(form, text="Record ID:").grid(row=0, column=0, sticky=tk.W, pady=4)
        ttk.Label(form, text=new_id, font=("Helvetica", 10, "bold")).grid(row=0, column=1, sticky=tk.W, pady=4)

        ttk.Label(form, text="Volunteer Name:").grid(row=1, column=0, sticky=tk.W, pady=4)
        name_entry = ttk.Entry(form, width=30)
        name_entry.grid(row=1, column=1, pady=4)

        ttk.Label(form, text="Date (YYYY-MM-DD):").grid(row=2, column=0, sticky=tk.W, pady=4)
        from datetime import date
        date_entry = ttk.Entry(form, width=30)
        date_entry.insert(0, date.today().strftime("%Y-%m-%d"))
        date_entry.grid(row=2, column=1, pady=4)

        ttk.Label(form, text="Organization:").grid(row=3, column=0, sticky=tk.W, pady=4)
        org_entry = ttk.Entry(form, width=30)
        org_entry.grid(row=3, column=1, pady=4)

        ttk.Label(form, text="Category:").grid(row=4, column=0, sticky=tk.W, pady=4)
        cat_combo = ttk.Combobox(form, values=CATEGORIES, state="readonly", width=28)
        cat_combo.current(0)
        cat_combo.grid(row=4, column=1, pady=4)

        ttk.Label(form, text="Hours Served:").grid(row=5, column=0, sticky=tk.W, pady=4)
        hours_entry = ttk.Entry(form, width=30)
        hours_entry.insert(0, "2.5")
        hours_entry.grid(row=5, column=1, pady=4)

        ttk.Label(form, text="Description:").grid(row=6, column=0, sticky=tk.W, pady=4)
        desc_entry = ttk.Entry(form, width=30)
        desc_entry.grid(row=6, column=1, pady=4)

        def save_action():
            name = name_entry.get().strip()
            date_val = date_entry.get().strip()
            org = org_entry.get().strip()
            cat = cat_combo.get().strip()
            hrs_val = hours_entry.get().strip()
            desc = desc_entry.get().strip()

            if len(name) < 2:
                messagebox.showerror("Validation Error", "Name must be at least 2 characters.", parent=dialog)
                return

            valid_date, d_err, _ = validate_date_string(date_val)
            if not valid_date:
                messagebox.showerror("Validation Error", f"Date Error: {d_err}", parent=dialog)
                return

            if not org:
                messagebox.showerror("Validation Error", "Organization cannot be empty.", parent=dialog)
                return

            valid_hrs, h_err, parsed_hrs = validate_hours(hrs_val)
            if not valid_hrs:
                messagebox.showerror("Validation Error", f"Hours Error: {h_err}", parent=dialog)
                return

            rec = VolunteerRecord(
                record_id=new_id,
                volunteer_name=name,
                date=date_val,
                organization=org,
                category=cat,
                hours=parsed_hrs,
                description=desc or "General volunteer activity."
            )

            self.records.append(rec)
            self.storage.save_records(self.records)
            self.refresh_table()
            self.update_summary_cards()
            dialog.destroy()
            messagebox.showinfo("Success", f"Activity {new_id} saved successfully!", parent=self.root)

        btn_save = ttk.Button(form, text="Save Record", command=save_action)
        btn_save.grid(row=7, column=1, sticky=tk.E, pady=15)


def launch_gui_window(records: List[VolunteerRecord], storage: StorageManager):
    """Entry function to launch Tkinter GUI."""
    root = tk.Tk()
    app = CampusCatalystGUI(root, records, storage)
    root.mainloop()
