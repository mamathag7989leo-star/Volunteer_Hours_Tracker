"""
models.py - Foundational data structures and business models.
"""

from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
import uuid

# Standard categories allowed across the system
CATEGORIES: List[str] = [
    "Community Service",
    "Education & Tutoring",
    "Environmental & Green Campus",
    "Healthcare & Wellbeing",
    "Animal Welfare",
    "Disaster Relief & Safety",
    "Campus Events & Athletics",
    "Arts & Culture"
]


@dataclass
class VolunteerRecord:
    record_id: str
    volunteer_name: str
    date: str              # Format: YYYY-MM-DD
    organization: str
    category: str
    hours: float
    description: str
    supervisor: str = "Self-Reported"
    created_at: str = ""

    def __post_init__(self):
        # Format hours to 2 decimal places and ensure created_at has a value
        self.hours = round(float(self.hours), 2)
        if not self.created_at:
            self.created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VolunteerRecord":
        return cls(
            record_id=str(data.get("record_id", "")),
            volunteer_name=str(data.get("volunteer_name", "")),
            date=str(data.get("date", "")),
            organization=str(data.get("organization", "")),
            category=str(data.get("category", "")),
            hours=float(data.get("hours", 0.0)),
            description=str(data.get("description", "")),
            supervisor=str(data.get("supervisor", "Self-Reported")),
            created_at=str(data.get("created_at", ""))
        )

    def matches_keyword(self, keyword: str) -> bool:
        kw = keyword.lower().strip()
        return (
            kw in self.record_id.lower() or
            kw in self.volunteer_name.lower() or
            kw in self.organization.lower() or
            kw in self.category.lower() or
            kw in self.description.lower() or
            kw in self.supervisor.lower()
        )
