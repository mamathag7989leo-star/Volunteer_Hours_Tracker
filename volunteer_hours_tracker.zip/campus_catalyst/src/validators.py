"""
validators.py - Defensive input validation routines and interactive input wrappers.
Centralizes input sanitization to prevent program crashes from invalid, non-numeric,
or out-of-boundary entries.
"""

import re
from datetime import datetime, date
from typing import List, Optional, Tuple, Any


def sanitize_text(text: str) -> str:
    """Strip leading/trailing spaces and collapse duplicate whitespace."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text.strip())


def validate_date_string(date_str: str) -> Tuple[bool, Optional[str], Optional[date]]:
    """
    Validates date string in YYYY-MM-DD format.
    Ensures date is valid calendar date and not in the future.
    Returns: (is_valid, error_message, parsed_date_object)
    """
    clean_date = sanitize_text(date_str)
    if not clean_date:
        return False, "Date cannot be empty.", None

    pattern = r"^\d{4}-\d{2}-\d{2}$"
    if not re.match(pattern, clean_date):
        return False, "Invalid format. Expected format is YYYY-MM-DD (e.g. 2026-03-15).", None

    try:
        parsed = datetime.strptime(clean_date, "%Y-%m-%d").date()
    except ValueError as e:
        return False, f"Invalid calendar date ({e}).", None

    today = date.today()
    if parsed > today:
        return False, f"Date cannot be in the future (today is {today.strftime('%Y-%m-%d')}).", None

    if parsed.year < 2000:
        return False, "Date cannot precede year 2000.", None

    return True, None, parsed


def validate_hours(hours_val: Any) -> Tuple[bool, Optional[str], float]:
    """
    Validates service hours. Range: 0.25 to 24.00 hours.
    Returns: (is_valid, error_message, parsed_float)
    """
    if hours_val is None:
        return False, "Hours field cannot be empty.", 0.0

    try:
        val = float(str(hours_val).strip())
    except (ValueError, TypeError):
        return False, "Hours must be a valid numeric number (e.g., 2, 4.5).", 0.0

    if val < 0.25:
        return False, "Service hours must be at least 0.25 hours (15 minutes).", 0.0

    if val > 24.0:
        return False, "Service hours cannot exceed 24.0 hours for a single day session.", 0.0

    return True, None, round(val, 2)


# =========================================================================
# Interactive Console Input Wrappers (loop until user provides valid input)
# =========================================================================

def prompt_non_empty(prompt_text: str, min_len: int = 2, max_len: int = 100) -> str:
    """Repeatedly prompts user until a non-empty string within length bounds is provided."""
    while True:
        try:
            raw = input(prompt_text)
        except (KeyboardInterrupt, EOFError):
            print("\n[Input cancelled]")
            raise
        sanitized = sanitize_text(raw)
        if len(sanitized) < min_len:
            print(f"  [!] Input must be at least {min_len} characters long. Please try again.")
            continue
        if len(sanitized) > max_len:
            print(f"  [!] Input exceeds {max_len} characters limit. Please shorten your entry.")
            continue
        return sanitized


def prompt_date(prompt_text: str = "Enter Date (YYYY-MM-DD) [or press Enter for today]: ") -> str:
    """Prompts for a date in YYYY-MM-DD format with Enter defaulting to today."""
    today_str = date.today().strftime("%Y-%m-%d")
    while True:
        try:
            raw = input(prompt_text).strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[Input cancelled]")
            raise
        if not raw:
            return today_str

        is_valid, err_msg, _ = validate_date_string(raw)
        if is_valid:
            return raw
        print(f"  [!] {err_msg}")


def prompt_hours(prompt_text: str = "Enter Hours Served (0.25 - 24.0): ") -> float:
    """Prompts for hours and loops until a valid float in range is entered."""
    while True:
        try:
            raw = input(prompt_text).strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[Input cancelled]")
            raise
        is_valid, err_msg, val = validate_hours(raw)
        if is_valid:
            if val >= 12.0:
                print(f"  [*] Notice: High duration session detected ({val} hours).")
            return val
        print(f"  [!] {err_msg}")


def prompt_category_choice(categories: List[str]) -> str:
    """Displays category menu and returns validated category choice."""
    print("\nSelect Category:")
    for idx, cat in enumerate(categories, 1):
        print(f"  [{idx}] {cat}")
    print(f"  [{len(categories) + 1}] Custom / Other")

    while True:
        try:
            raw = input(f"Select option (1-{len(categories) + 1}): ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n[Input cancelled]")
            raise
        if raw.isdigit():
            choice = int(raw)
            if 1 <= choice <= len(categories):
                return categories[choice - 1]
            if choice == len(categories) + 1:
                return prompt_non_empty("Enter Custom Category Name: ", min_len=3, max_len=40)
        print(f"  [!] Please select a number between 1 and {len(categories) + 1}.")


def prompt_yes_no(prompt_text: str, default: bool = True) -> bool:
    """Prompts user for (y/n) confirmation."""
    default_hint = "[Y/n]" if default else "[y/N]"
    while True:
        try:
            raw = input(f"{prompt_text} {default_hint}: ").strip().lower()
        except (KeyboardInterrupt, EOFError):
            return default
        if not raw:
            return default
        if raw in ("y", "yes", "true", "1"):
            return True
        if raw in ("n", "no", "false", "0"):
            return False
        print("  [!] Please answer with 'y' (yes) or 'n' (no).")
