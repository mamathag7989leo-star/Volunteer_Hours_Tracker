"""
Volunteer Hours Tracker
Package initialization.
"""

__version__ = "1.0.0"
__author__ = "Volunteer Hours Tracker Team"
