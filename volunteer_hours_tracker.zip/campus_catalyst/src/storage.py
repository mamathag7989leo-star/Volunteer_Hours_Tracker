"""
storage.py - Resilient local data persistence module for JSON and CSV.
Handles missing directories, corrupted files, graceful fallback, and sequential ID generation.
"""

import json
import csv
import os
import shutil
from datetime import datetime
from typing import List, Tuple, Optional
from models import VolunteerRecord

DEFAULT_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
DEFAULT_JSON_PATH = os.path.join(DEFAULT_DATA_DIR, "volunteer_records.json")
DEFAULT_CSV_PATH = os.path.join(DEFAULT_DATA_DIR, "volunteer_records.csv")


class StorageManager:
    """Manages persistent record storage with automatic error recovery."""

    def __init__(self, data_path: Optional[str] = None):
        self.data_path = data_path or DEFAULT_JSON_PATH
        self.ensure_directory_exists()

    def ensure_directory_exists(self) -> None:
        """Ensures the enclosing directory for data files exists."""
        directory = os.path.dirname(self.data_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory, exist_ok=True)

    def load_records(self) -> Tuple[List[VolunteerRecord], Optional[str]]:
        """
        Loads records from JSON storage.
        Returns: (records_list, status_message_or_warning)
        """
        self.ensure_directory_exists()

        if not os.path.exists(self.data_path):
            # Create an empty template file
            self.save_records([])
            return [], f"Storage file initialized at: {self.data_path}"

        try:
            with open(self.data_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    return [], "Notice: Storage file was empty; initialized blank database."
                raw_data = json.loads(content)

            if not isinstance(raw_data, list):
                raise ValueError("Expected JSON root to be a list of records.")

            records = []
            for item in raw_data:
                try:
                    records.append(VolunteerRecord.from_dict(item))
                except Exception as err:
                    # Skip malformed record but keep loading valid ones
                    continue

            return records, None

        except (json.JSONDecodeError, ValueError) as err:
            # Handle corrupted file: backup and start clean template
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = f"{self.data_path}.corrupt_{timestamp}.bak"
            shutil.copyfile(self.data_path, backup_path)
            self.save_records([])
            return [], (
                f"[WARNING] Corrupted storage file encountered: {err}.\n"
                f"A backup of the damaged file was saved to: {backup_path}\n"
                f"A fresh database template has been created."
            )

        except Exception as err:
            return [], f"[ERROR] Unexpected I/O error while reading {self.data_path}: {err}"

    def save_records(self, records: List[VolunteerRecord]) -> bool:
        """
        Persists list of records to storage in atomic JSON write.
        """
        self.ensure_directory_exists()
        temp_path = self.data_path + ".tmp"
        try:
            data = [r.to_dict() for r in records]
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            # Atomic replace
            if os.path.exists(self.data_path):
                os.replace(temp_path, self.data_path)
            else:
                os.rename(temp_path, self.data_path)
            return True
        except Exception as e:
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except OSError:
                    pass
            print(f"  [!] Storage save failure: {e}")
            return False

    def export_csv(self, records: List[VolunteerRecord], csv_path: str = DEFAULT_CSV_PATH) -> bool:
        """Exports records into standardized CSV format."""
        try:
            os.makedirs(os.path.dirname(os.path.abspath(csv_path)), exist_ok=True)
            fieldnames = [
                "record_id", "volunteer_name", "date", "organization",
                "category", "hours", "description", "supervisor", "created_at"
            ]
            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for r in records:
                    writer.writerow(r.to_dict())
            return True
        except Exception as e:
            print(f"  [!] CSV export failed: {e}")
            return False

    @staticmethod
    def generate_next_id(records: List[VolunteerRecord], prefix: str = "VOL-") -> str:
        """Generates sequential ID like VOL-1001, VOL-1002, etc."""
        highest_num = 1000
        for r in records:
            if r.record_id.startswith(prefix):
                num_part = r.record_id[len(prefix):]
                if num_part.isdigit():
                    val = int(num_part)
                    if val > highest_num:
                        highest_num = val
        return f"{prefix}{highest_num + 1}"
