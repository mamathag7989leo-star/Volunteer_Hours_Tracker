"""
run_tests.py - Test discovery and execution script for Volunteer Hours Tracker.
Runs all unit tests across models, validators, storage, analytics, and importer.
"""

import unittest
import sys
import os

if __name__ == "__main__":
    test_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests")
    print(f"Discovering and running tests in: {test_dir}\n")
    loader = unittest.TestLoader()
    suite = loader.discover(start_dir=test_dir, pattern="test_*.py")
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
