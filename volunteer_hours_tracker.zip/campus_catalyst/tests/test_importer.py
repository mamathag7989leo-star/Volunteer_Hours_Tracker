"""
test_importer.py - Unit tests for bulk CSV import and row-by-row defensive validation.
"""

import unittest
import tempfile
import os
import csv
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from models import VolunteerRecord
from importer import import_csv_dataset


class TestImporter(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.csv_file = os.path.join(self.temp_dir.name, "batch_test.csv")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_import_valid_and_invalid_rows(self):
        # Create CSV with 1 valid row, 1 invalid date, 1 invalid hours
        rows = [
            ["volunteer_name", "date", "organization", "category", "hours", "description"],
            ["Rachel Zane", "2026-02-10", "Legal Aid", "Community Service", "3.5", "Client intakes"],
            ["Mike Ross", "bad-date", "Legal Aid", "Community Service", "2.0", "Research"],
            ["Harvey Specter", "2026-02-12", "Legal Aid", "Community Service", "not-a-number", "Pro bono"],
        ]

        with open(self.csv_file, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerows(rows)

        existing: list[VolunteerRecord] = []
        new_recs, report = import_csv_dataset(self.csv_file, existing)

        self.assertEqual(report.total_rows_read, 3)
        self.assertEqual(report.valid_rows_imported, 1)
        self.assertEqual(report.skipped_rows, 2)
        self.assertEqual(len(new_recs), 1)
        self.assertEqual(new_recs[0].volunteer_name, "Rachel Zane")
        self.assertEqual(new_recs[0].hours, 3.5)


if __name__ == "__main__":
    unittest.main()
