"""
test_analytics.py - Unit tests for analytics, metrics aggregations, and anomaly flags.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from models import VolunteerRecord
from analytics import compute_executive_summary, filter_records


class TestAnalytics(unittest.TestCase):

    def setUp(self):
        self.records = [
            VolunteerRecord("VOL-1001", "Maya", "2026-02-01", "Hospital", "Healthcare", 4.0, "Patient care"),
            VolunteerRecord("VOL-1002", "Maya", "2026-02-02", "Food Bank", "Community Service", 3.0, "Food distribution"),
            VolunteerRecord("VOL-1003", "Alex", "2026-02-03", "Shelter", "Community Service", 5.0, "Shelter upkeep"),
            # Anomaly: Single session >= 10h
            VolunteerRecord("VOL-1004", "Jordan", "2026-02-04", "Disaster Site", "Disaster Relief", 11.0, "Flood response"),
        ]

    def test_compute_executive_summary_aggregations(self):
        summary = compute_executive_summary(self.records)
        self.assertEqual(summary.total_records, 4)
        self.assertEqual(summary.total_hours, 23.0)
        self.assertEqual(summary.avg_hours_per_session, 5.75)
        self.assertEqual(summary.unique_volunteers, 3)

        # Check category breakdown
        self.assertEqual(summary.category_breakdown["Community Service"], 8.0)
        self.assertEqual(summary.category_breakdown["Disaster Relief"], 11.0)

        # Check leaderboard
        top_volunteer = summary.volunteer_leaderboard[0]
        self.assertEqual(top_volunteer["volunteer"], "Jordan")
        self.assertEqual(top_volunteer["total_hours"], 11.0)

    def test_anomaly_detection(self):
        summary = compute_executive_summary(self.records)
        self.assertTrue(len(summary.anomalies) >= 1)
        found_high_session = any(a["type"] == "HIGH_SINGLE_SESSION" and a["volunteer"] == "Jordan" for a in summary.anomalies)
        self.assertTrue(found_high_session)

    def test_filter_records(self):
        # Filter by keyword
        res = filter_records(self.records, keyword="Hospital")
        self.assertEqual(len(res), 1)
        self.assertEqual(res[0].record_id, "VOL-1001")

        # Filter by category
        res2 = filter_records(self.records, category="Community Service")
        self.assertEqual(len(res2), 2)

        # Filter by volunteer
        res3 = filter_records(self.records, volunteer="maya")
        self.assertEqual(len(res3), 2)


if __name__ == "__main__":
    unittest.main()
