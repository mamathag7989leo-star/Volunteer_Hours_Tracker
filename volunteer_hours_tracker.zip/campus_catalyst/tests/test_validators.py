"""
test_validators.py - Unit tests for defensive validation logic.
"""

import unittest
from datetime import date, timedelta
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from validators import sanitize_text, validate_date_string, validate_hours


class TestValidators(unittest.TestCase):

    def test_sanitize_text(self):
        self.assertEqual(sanitize_text("  hello   world  "), "hello world")
        self.assertEqual(sanitize_text(""), "")
        self.assertEqual(sanitize_text(None), "")

    def test_validate_date_string_valid(self):
        valid, err, dt = validate_date_string("2026-02-15")
        self.assertTrue(valid)
        self.assertIsNone(err)
        self.assertEqual(dt.year, 2026)
        self.assertEqual(dt.month, 2)
        self.assertEqual(dt.day, 15)

    def test_validate_date_string_invalid_format(self):
        valid, err, _ = validate_date_string("15-02-2026")
        self.assertFalse(valid)
        self.assertIn("Invalid format", err)

        valid2, err2, _ = validate_date_string("not-a-date")
        self.assertFalse(valid2)

    def test_validate_date_string_future_rejection(self):
        tomorrow = date.today() + timedelta(days=1)
        future_str = tomorrow.strftime("%Y-%m-%d")
        valid, err, _ = validate_date_string(future_str)
        self.assertFalse(valid)
        self.assertIn("future", err.lower())

    def test_validate_date_string_ancient_date(self):
        valid, err, _ = validate_date_string("1998-05-12")
        self.assertFalse(valid)
        self.assertIn("2000", err)

    def test_validate_hours_valid(self):
        valid, err, val = validate_hours("3.5")
        self.assertTrue(valid)
        self.assertEqual(val, 3.5)

        valid2, _, val2 = validate_hours(0.5)
        self.assertTrue(valid2)
        self.assertEqual(val2, 0.5)

    def test_validate_hours_invalid(self):
        # Non-numeric
        valid, err, _ = validate_hours("three")
        self.assertFalse(valid)
        self.assertIn("numeric", err)

        # Negative
        valid, err, _ = validate_hours("-2.0")
        self.assertFalse(valid)

        # Below 0.25h
        valid, err, _ = validate_hours("0.1")
        self.assertFalse(valid)
        self.assertIn("0.25", err)

        # Above 24.0h
        valid, err, _ = validate_hours("25.0")
        self.assertFalse(valid)
        self.assertIn("24.0", err)


if __name__ == "__main__":
    unittest.main()
