"""
test_models.py - Unit tests for VolunteerRecord model.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from models import VolunteerRecord


class TestVolunteerRecord(unittest.TestCase):

    def test_record_creation_and_rounding(self):
        rec = VolunteerRecord(
            record_id="VOL-1001",
            volunteer_name="Alice Smith",
            date="2026-02-15",
            organization="Animal Shelter",
            category="Animal Welfare",
            hours=3.456,
            description="Dog walking and feeding"
        )
        self.assertEqual(rec.record_id, "VOL-1001")
        self.assertEqual(rec.hours, 3.46)
        self.assertTrue(len(rec.created_at) > 0)

    def test_to_dict_and_from_dict(self):
        rec = VolunteerRecord(
            record_id="VOL-1002",
            volunteer_name="Bob Jones",
            date="2026-02-16",
            organization="Food Pantry",
            category="Community Service",
            hours=4.0,
            description="Packing boxes",
            supervisor="Jane Doe"
        )
        d = rec.to_dict()
        self.assertEqual(d["record_id"], "VOL-1002")
        self.assertEqual(d["supervisor"], "Jane Doe")

        restored = VolunteerRecord.from_dict(d)
        self.assertEqual(restored.record_id, rec.record_id)
        self.assertEqual(restored.volunteer_name, rec.volunteer_name)
        self.assertEqual(restored.hours, rec.hours)

    def test_matches_keyword(self):
        rec = VolunteerRecord(
            record_id="VOL-1003",
            volunteer_name="Charlie Brown",
            date="2026-02-17",
            organization="Green Earth Initiative",
            category="Environmental & Green Campus",
            hours=2.5,
            description="Tree planting on campus"
        )
        self.assertTrue(rec.matches_keyword("charlie"))
        self.assertTrue(rec.matches_keyword("VOL-1003"))
        self.assertTrue(rec.matches_keyword("plant"))
        self.assertTrue(rec.matches_keyword("Earth"))
        self.assertFalse(rec.matches_keyword("Hospital"))


if __name__ == "__main__":
    unittest.main()
