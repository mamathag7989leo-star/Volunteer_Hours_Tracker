"""
test_storage.py - Unit tests for persistence, auto-healing, and ID generation.
"""

import unittest
import tempfile
import os
import json
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))
from models import VolunteerRecord
from storage import StorageManager


class TestStorageManager(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.storage_file = os.path.join(self.temp_dir.name, "test_records.json")
        self.storage = StorageManager(self.storage_file)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_load_when_file_not_existing(self):
        records, msg = self.storage.load_records()
        self.assertEqual(len(records), 0)
        self.assertTrue(os.path.exists(self.storage_file))

    def test_save_and_reload_records(self):
        records = [
            VolunteerRecord("VOL-1001", "Jane", "2026-02-10", "Red Cross", "Healthcare", 3.0, "Assisting doctors"),
            VolunteerRecord("VOL-1002", "Mark", "2026-02-11", "Food Pantry", "Community", 2.0, "Stocking shelves")
        ]
        saved = self.storage.save_records(records)
        self.assertTrue(saved)

        loaded, msg = self.storage.load_records()
        self.assertEqual(len(loaded), 2)
        self.assertEqual(loaded[0].volunteer_name, "Jane")
        self.assertEqual(loaded[1].hours, 2.0)

    def test_corrupted_json_auto_recovery(self):
        # Write corrupted JSON to storage
        with open(self.storage_file, "w", encoding="utf-8") as f:
            f.write("{corrupt json content missing brackets")

        records, warning = self.storage.load_records()
        self.assertEqual(len(records), 0)
        self.assertIn("WARNING", warning)
        # Check that backup was created
        dir_files = os.listdir(self.temp_dir.name)
        backup_files = [f for f in dir_files if "corrupt" in f and f.endswith(".bak")]
        self.assertTrue(len(backup_files) >= 1)

    def test_generate_next_id(self):
        records = [
            VolunteerRecord("VOL-1001", "Jane", "2026-02-10", "Red Cross", "Healthcare", 3.0, "Assisting doctors"),
            VolunteerRecord("VOL-1005", "Mark", "2026-02-11", "Food Pantry", "Community", 2.0, "Stocking shelves")
        ]
        next_id = StorageManager.generate_next_id(records)
        self.assertEqual(next_id, "VOL-1006")


if __name__ == "__main__":
    unittest.main()
