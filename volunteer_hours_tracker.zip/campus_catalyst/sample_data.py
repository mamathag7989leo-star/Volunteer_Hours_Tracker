"""
sample_data.py - Realistic sample dataset generator for Volunteer Hours Tracker.
Contains 42 diverse, realistic entries with normal cases, boundary values,
and edge conditions (e.g., min hours, max hours, anomaly flags).
"""

import os
import sys
import json
import csv

# Ensure src/ is importable
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(CURRENT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from models import VolunteerRecord


RAW_SAMPLE_DATA = [
    # Normal entries - Education & Tutoring
    ("VOL-1001", "Maya Lin", "2026-02-02", "Campus Tutoring Center", "Education & Tutoring", 3.0, "Math & Physics tutoring for freshmen", "Prof. Hastings"),
    ("VOL-1002", "Alex Rivera", "2026-02-03", "City Library Literacy Program", "Education & Tutoring", 2.5, "Reading companion for elementary school students", "Sarah Jenkins"),
    ("VOL-1003", "Jordan Patel", "2026-02-05", "Campus Coding Club", "Education & Tutoring", 4.0, "Introductory Python workshop mentorship", "Dr. Vance"),
    ("VOL-1004", "Maya Lin", "2026-02-08", "Campus Tutoring Center", "Education & Tutoring", 3.5, "Organic Chemistry study circle coordination", "Prof. Hastings"),
    ("VOL-1005", "Marcus Thorne", "2026-02-10", "STEM For All Initiative", "Education & Tutoring", 5.0, "Hands-on robotics demo at regional high school", "Elena Rostova"),
    
    # Environmental & Green Campus
    ("VOL-1006", "Priya Sharma", "2026-02-04", "Campus Green Initiative", "Environmental & Green Campus", 4.0, "E-waste collection drive and sorting", "Mark Davis"),
    ("VOL-1007", "David Kim", "2026-02-07", "Urban Forest Conservancy", "Environmental & Green Campus", 6.0, "Native tree planting and trail restoration", "Ranger Miller"),
    ("VOL-1008", "Alex Rivera", "2026-02-12", "River Cleanup Coalition", "Environmental & Green Campus", 4.5, "Waterway debris collection and water sampling", "Laura Chen"),
    ("VOL-1009", "Priya Sharma", "2026-02-15", "Campus Community Garden", "Environmental & Green Campus", 2.0, "Soil preparation, compost aeration, and seeding", "Mark Davis"),
    ("VOL-1010", "Carlos Mendoza", "2026-02-18", "Solar Campus Project", "Environmental & Green Campus", 3.5, "Assisted energy audit of campus science buildings", "Dr. Franklin"),

    # Community Service & Food Pantry
    ("VOL-1011", "Samantha Reed", "2026-02-01", "Metropolitan Food Bank", "Community Service", 4.0, "Canned goods inventorying, packing, and distribution", "Pastor Tom"),
    ("VOL-1012", "Aisha Al-Mansoor", "2026-02-06", "Hope Shelter Alliance", "Community Service", 5.0, "Evening meal preparation and dining hall coordination", "Martha Higgins"),
    ("VOL-1013", "Elena Gomez", "2026-02-09", "Downtown Community Kitchen", "Community Service", 3.5, "Soup kitchen food prep and service", "Chef Gordon"),
    ("VOL-1014", "Liam O'Connor", "2026-02-14", "Habitat for Humanity", "Community Service", 7.0, "Drywall installation and residential framing", "Foreman Bob"),
    ("VOL-1015", "Samantha Reed", "2026-02-17", "Metropolitan Food Bank", "Community Service", 3.0, "Emergency family food box logistics", "Pastor Tom"),
    ("VOL-1016", "Jordan Patel", "2026-02-20", "Campus Thrift Store", "Community Service", 2.5, "Donation intake, sorting, and merchandising", "Rachel Green"),

    # Healthcare & Wellbeing
    ("VOL-1017", "Marcus Thorne", "2026-02-03", "St. Jude Community Hospital", "Healthcare & Wellbeing", 4.0, "Patient check-in assistance and wayfinding", "Nurse Ratcliffe"),
    ("VOL-1018", "David Kim", "2026-02-11", "Red Cross Blood Drive", "Healthcare & Wellbeing", 6.0, "Donor registration, refreshment station management", "Dr. Aris"),
    ("VOL-1019", "Elena Gomez", "2026-02-16", "Elder Care Sunshine Home", "Healthcare & Wellbeing", 3.0, "Music therapy session and wheelchair transport", "Linda Blair"),
    ("VOL-1020", "Marcus Thorne", "2026-02-22", "St. Jude Community Hospital", "Healthcare & Wellbeing", 5.5, "Pediatric ward craft activities and story time", "Nurse Ratcliffe"),

    # Animal Welfare
    ("VOL-1021", "Maya Lin", "2026-02-06", "City Animal Rescue Center", "Animal Welfare", 3.5, "Canine socialization, kennel sanitation, and feeding", "Officer Barnes"),
    ("VOL-1022", "Carlos Mendoza", "2026-02-13", "Happy Tails Wildlife Sanctuary", "Animal Welfare", 5.0, "Bird enclosure repair and rehabilitation feeds", "Dr. Doolittle"),
    ("VOL-1023", "Maya Lin", "2026-02-19", "City Animal Rescue Center", "Animal Welfare", 2.5, "Adoption fair booth staffing and photography", "Officer Barnes"),
    ("VOL-1024", "Samantha Reed", "2026-02-25", "Feline Friends Shelter", "Animal Welfare", 3.0, "Cat socialization and medication schedule log", "Chloe Walsh"),

    # Disaster Relief & Safety
    ("VOL-1025", "Liam O'Connor", "2026-02-07", "Community Emergency Response Team", "Disaster Relief & Safety", 8.0, "First aid station staging and triage logistics simulation", "Capt. Briggs"),
    ("VOL-1026", "Aisha Al-Mansoor", "2026-02-12", "Red Cross Disaster Relief", "Disaster Relief & Safety", 6.5, "Emergency hygiene kit assembly and warehousing", "Commander Vance"),
    ("VOL-1027", "Carlos Mendoza", "2026-02-21", "Campus Safety Patrol", "Disaster Relief & Safety", 4.0, "Night walk safe escort and emergency call box inspection", "Sgt. Hayes"),

    # Campus Events & Athletics
    ("VOL-1028", "Jordan Patel", "2026-02-02", "Special Olympics Regional Meet", "Campus Events & Athletics", 6.0, "Track & Field event judging and medal presentations", "Coach Sullivan"),
    ("VOL-1029", "Priya Sharma", "2026-02-18", "Annual Campus Marathon", "Campus Events & Athletics", 5.0, "Hydration station management and medical checkpoint relay", "Coach Taylor"),
    ("VOL-1030", "Alex Rivera", "2026-02-24", "Collegiate Career Fair", "Campus Events & Athletics", 3.5, "Employer setup, candidate guidance, and audio/visual setup", "Dean Henderson"),

    # Arts & Culture
    ("VOL-1031", "Elena Gomez", "2026-02-05", "Campus Fine Arts Museum", "Arts & Culture", 3.0, "Exhibition docent and visitor badge verification", "Curator Moreau"),
    ("VOL-1032", "Aisha Al-Mansoor", "2026-02-15", "Youth Community Symphony", "Arts & Culture", 4.0, "Stage management, seating logistics, and ticket scanning", "Maestro Chen"),

    # --- Boundary and Edge Case Entries ---
    # Boundary: Minimum duration session (0.5 hour)
    ("VOL-1033", "Alex Rivera", "2026-02-26", "Campus Blood Drive", "Healthcare & Wellbeing", 0.5, "Emergency donor check-in relief shift", "Dr. Aris"),
    # Boundary: Short 0.75 hour session
    ("VOL-1034", "David Kim", "2026-02-27", "Library Book Drive", "Education & Tutoring", 0.75, "Quick book sorting and unboxing", "Sarah Jenkins"),
    # Anomaly / High-Duration: 10.5 hours session (Triggers Anomaly Warning)
    ("VOL-1035", "Liam O'Connor", "2026-02-28", "Flood Emergency Response", "Disaster Relief & Safety", 10.5, "Continuous sandbagging and floodwall staging operation", "Chief Kelly"),
    # Anomaly / High-Duration: 12.0 hours marathon shift (Triggers Anomaly Warning)
    ("VOL-1036", "Aisha Al-Mansoor", "2026-03-01", "Winter Shelter Emergency", "Community Service", 12.0, "Overnight emergency cold shelter intake & supervision", "Martha Higgins"),
    # Same Day Multiple Session by Maya Lin on 2026-03-02
    ("VOL-1037", "Maya Lin", "2026-03-02", "Morning Animal Rescue", "Animal Welfare", 4.0, "Morning veterinary round assistance", "Officer Barnes"),
    ("VOL-1038", "Maya Lin", "2026-03-02", "Evening Animal Rescue", "Animal Welfare", 3.5, "Evening feeding and kennel deep cleaning", "Officer Barnes"),
    
    # Milestone booster entries
    ("VOL-1039", "Samantha Reed", "2026-03-03", "Metropolitan Food Bank", "Community Service", 4.5, "Weekly distribution leader", "Pastor Tom"),
    ("VOL-1040", "Jordan Patel", "2026-03-04", "Robotics Club Mentorship", "Education & Tutoring", 5.0, "High school hackathon judging", "Dr. Vance"),
    ("VOL-1041", "Priya Sharma", "2026-03-05", "Campus Arboretum", "Environmental & Green Campus", 3.5, "Botanical labeling and cataloging", "Mark Davis"),
    ("VOL-1042", "Marcus Thorne", "2026-03-06", "St. Jude Hospital", "Healthcare & Wellbeing", 4.0, "Rehabilitation wing visitor coordinator", "Nurse Ratcliffe"),
]


def generate_sample_records() -> list[VolunteerRecord]:
    """Returns list of 42 pre-configured VolunteerRecord objects."""
    records = []
    for item in RAW_SAMPLE_DATA:
        rec = VolunteerRecord(
            record_id=item[0],
            volunteer_name=item[1],
            date=item[2],
            organization=item[3],
            category=item[4],
            hours=item[5],
            description=item[6],
            supervisor=item[7]
        )
        records.append(rec)
    return records


def main():
    """Seeds JSON and CSV files into data/ and sample_data/ directories."""
    records = generate_sample_records()
    
    # Target directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    sample_dir = os.path.join(base_dir, "sample_data")
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(sample_dir, exist_ok=True)

    json_path = os.path.join(data_dir, "volunteer_records.json")
    csv_path = os.path.join(sample_dir, "sample_dataset.csv")

    # Save JSON
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump([r.to_dict() for r in records], f, indent=2)
    print(f"[OK] Generated {len(records)} records in JSON: {json_path}")

    # Save CSV
    fieldnames = [
        "record_id", "volunteer_name", "date", "organization",
        "category", "hours", "description", "supervisor", "created_at"
    ]
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in records:
            writer.writerow(r.to_dict())
    print(f"[OK] Generated sample CSV dataset: {csv_path}")


if __name__ == "__main__":
    main()
