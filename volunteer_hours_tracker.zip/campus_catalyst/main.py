"""
main.py - Automated calculation of individual and overall service hrs.
"""

import sys
import os

# Ensure src/ directory is discoverable
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(CURRENT_DIR, "src")
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from cli import CommandLineInterface
from storage import StorageManager


def main():
    """Application launcher supporting CLI and optional GUI launch flag."""
    if "--gui" in sys.argv:
        try:
            from gui import launch_gui_window
            storage = StorageManager()
            records, _ = storage.load_records()
            print("Launching Volunteer Hours Tracker Graphical User Interface...")
            launch_gui_window(records, storage)
            return
        except Exception as e:
            print(f"Could not initialize GUI ({e}). Falling back to Terminal CLI.\n")

    cli = CommandLineInterface()
    cli.run()


if __name__ == "__main__":
    main()
